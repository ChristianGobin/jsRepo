let val = document.getElementById("Counter");
let count = 0;

val.innerText = count;

document.getElementById("Increment").addEventListener("click", ()=>{
  count++;
  val.innerText = count;
})

document.getElementById("Decrement").addEventListener("click", () => {
  count--;
  val.innerText = count;
})